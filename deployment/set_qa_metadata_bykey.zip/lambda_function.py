import os
import time
import json
import boto3
from contextlib import closing
import tempfile
import urllib3
from botocore.exceptions import ClientError
import json
import decimal
from boto3.dynamodb.conditions import Key, Attr




# global variables

DDB_TABLE = 'vr-demo'
S3_BUCKET = os.getenv('S3_BUCKET')
S3_PREFIX = 'material/mp3/'
WEB_PREFIX= os.getenv('CLOUDFRONT_PREFIX')
QA_ROOTPATH=os.getenv('QA_ROOTPATH')
cors = {
    "Access-Control-Allow-Headers" : "Content-Type",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
}

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return str(o)
        return super(DecimalEncoder, self).default(o)
        
languageCode = 'cmn-CN'
voiceId = 'Zhiyu'
speed_prefix = '<prosody rate="medium">'
camera='side_stand'
question=''
template='我是数字助手，请问如何帮助您'


def lambda_handler(event, context):

    # print(event, type(event))
    data = json.loads(event.get('body'))
    # print(data, type(data))
    user_id=data.get('user_id','')
    index = data.get('id', '')
    text = data.get('text', '')
    image_url = data.get('image_url', '')
    character=data.get('character','')
    voice=data.get('voice','')
    scene=data.get('scene','')
    action=data.get('action','')
    item_id=data.get('item_id','')
    voice_speed=data.get('voice_speed','')
    vr_module=data.get('vr_module','')
    camera=data.get('camera','')
    role=data.get('role')
    print('选择角色')
    
    if role=='role_tourist_guide':
        languageCode='cmn-CN'
        voiceId='Zhiyu'
        character='rp_emma_female_white'
        template='你是一名导游，名叫小林，请用风趣的方式，30字以内，回答如下问题:'
        question=text
        llmurl=(
        QA_ROOTPATH
        +"langchain_processor_qa?query="
        +template
        +question
        +"&task=chat"
        +"&language=chinese"
        +"&embedding_endpoint_name=uggingface-inference-eb"
        +"&llm_embedding_name=pytorch-inference-llm-v1"
        +"&index=smart_search_qa_test&top_k=1&cal_query_answer_score=true"
        )
    # if role=='role_tourist_guide':
    #     languageCode='cmn-CN'
    #     voiceId='Zhiyu'
    #     character='rp_emma_female_white'
    #     question=text
    #     llmurl= ('https://se59om7jhl.execute-api.us-west-2.amazonaws.com/prod/langchain_processor_qa?query='
    #     +question
    #     +'&task=qa&language=chinese&embedding_endpoint_name=huggingface-inference-eb&llm_embedding_name=pytorch-inference-llm-v1&'
    #     +'''prompt=你是一个客服人员，任务是根据客服回复记录，简单回答用户的问题，请严格按照客服回复记录回答，如果你不知道答案，就说你不知道，不要试图编造答案。答案以‘亲~’开头
    #     用户问题: {question}
    #     提问记录和回复记录：\n
    #     =========\n
    #     {context}\n
    #     =========\n
    #     答案:\n '''
    #     +'&search_engine=opensearch&index=doc_sxwx&top_k=1&cal_query_answer_score=true')
        
        
    elif role=='role_expert_AWS':
        languageCode='cmn-CN'
        voiceId='Zhiyu'
        character='rp_rin_female_asian'
        template='你是一名亚马逊云科技专家，名叫艾玛，请用专业的方式，30字以内，回答如下问题:'
        question=text
        llmurl=(
        QA_ROOTPATH
        +"langchain_processor_qa?query="
        +template
        +question
        +"&task=chat"
        +"&language=chinese"
        +"&embedding_endpoint_name=uggingface-inference-eb"
        +"&llm_embedding_name=pytorch-inference-llm-v1"
        +"&index=smart_search_qa_test&top_k=1&cal_query_answer_score=true"
        )
  
    elif role=='role_expert_auto_en':
        languageCode='en-GB'
        voiceId='Brian'  
        character='rp_kai_male_white'
        template='你是一名汽车领域的专家，名字叫做Kai，请用专业的方式，20字以内，使用英语回答下面问题:'
        question=text
        llmurl=(
        QA_ROOTPATH
        +"langchain_processor_qa?query="
        +template
        +question
        +"&task=chat"
        +"&language=chinese"
        +"&embedding_endpoint_name=uggingface-inference-eb"
        +"&llm_embedding_name=pytorch-inference-llm-v1"
        +"&index=smart_search_qa_test&top_k=1&cal_query_answer_score=true"
        )
    
    elif role=='role_3D_avatar_en':
        languageCode='en-GB'
        voiceId='Brian'  
        character='rp_ming_male_asian'
        template='你是Ming Qi的数字分身，请用活泼的方式，30字以内，使用英语回答如下问题:'
        question=text
        llmurl=(
        QA_ROOTPATH
        +"langchain_processor_qa?query="
        +template
        +question
        +"&task=chat"
        +"&language=chinese"
        +"&embedding_endpoint_name=uggingface-inference-eb"
        +"&llm_embedding_name=pytorch-inference-llm-v1"
        +"&index=smart_search_qa_test&top_k=1&cal_query_answer_score=true"
        )
    
    elif role=='role_expert_auto_cn':
        languageCode='cmn-CN'
        voiceId='Zhiyu'
        character='rp_deloris_female_asian'
        template='你是一名医疗健康的专家，名叫小美，请用专业的方式，30字以内，回答如下问题:'
        question=text
        llmurl=(
        QA_ROOTPATH
        +"langchain_processor_qa?query="
        +template
        +question
        +"&task=chat"
        +"&language=chinese"
        +"&embedding_endpoint_name=uggingface-inference-eb"
        +"&llm_embedding_name=pytorch-inference-llm-v1"
        +"&index=smart_search_qa_test&top_k=1&cal_query_answer_score=true"
        )
    

    print('等待智能搜索，大语言模型回复。。。。')
    
    # print(user_id)
    # print(index)
    print(llmurl)
    

    http = urllib3.PoolManager()
    res_answer = http.request('GET', llmurl)
  
    res_answer_data = res_answer.data.decode('utf-8')
    print(res_answer_data)
    res_answer_data = json.loads(res_answer_data)
    print(res_answer_data)
    #res_answer_data=json.loads(res_answer_data)
    text=res_answer_data.get('suggestion_answer')
    print('智能搜索，大语言模型回复:', text)
        
    if len(text) == 0:
        text="."
        
    if voice_speed=='medium' or voice_speed=='':
        speed_prefix='<prosody rate="medium">'
    elif voice_speed=='slow':
        speed_prefix='<prosody rate="slow">'
    elif voice_speed=='x-slow':
        speed_prefix='<prosody rate="x-slow">'
    elif voice_speed=='fast':
        speed_prefix='<prosody rate="fast">'
    elif voice_speed=='x-fast':
        speed_prefix='<prosody rate="x-fast">'
    else:
        speed_prefix='<prosody rate="medium">'

    ssmltext='<speak>'+speed_prefix+text+'</prosody></speak>'
    
    
    
    # if voice=='Zhiyu-CHN':
    #     languageCode='cmn-CN'
    #     voiceId='Zhiyu'
    # elif voice=='US-En-Male':
    #     languageCode='en-US'
    #     voiceId='Joey'
    # elif voice=='US-En-Female':
    #     languageCode='en-US'
    #     voiceId='Salli'
    # elif voice=='UK-En-Male':
    #     languageCode='en-GB'
    #     voiceId='Brian'    
    # elif voice=='UK-En-Female':
    #     languageCode='en-GB'
    #     voiceId='Emma'
    # elif voice=='fr-FR-Female':
    #     languageCode='fr-FR'
    #     voiceId='Lea'
    # elif voice=='DE-Female':
    #     languageCode='de-DE'
    #     voiceId='Vicki'  
    # elif voice=='DE-Male':
    #     languageCode='de-DE'
    #     voiceId='Daniel'  
        
    #generate mp3 file name, reuse image name
    
    image_file = image_url.split('/')[-1]

    base_filename = str(int(time.time()))
    
    dest_mp3_s3_url = S3_PREFIX + base_filename + '.mp3'

    # print(dest_mp3_s3_url)
    # print(WEB_PREFIX + dest_mp3_s3_url)
    print('文字转语音。。。')
    

    c = boto3.client('polly',region_name='us-east-1')
    
    
    rs = c.synthesize_speech(
        # Engine='standard',
        Engine='neural',
        LanguageCode=languageCode,
        OutputFormat='mp3',
        Text=ssmltext,
        # TextType='text',
        TextType='ssml',
        VoiceId=voiceId
    )
    
    s3 = boto3.client('s3')
    with tempfile.NamedTemporaryFile('ab') as ntf:
        with closing(rs['AudioStream']) as stream:
            #body = stream.read()
            ntf.write(stream.read())
            #ntf.seek(0)
            s3.upload_file(ntf.name, S3_BUCKET, dest_mp3_s3_url, ExtraArgs={'ContentType': "audio/mpeg"})
   
            print('文字转语音完成')
            # print('blendshape生成中。。。')
       
            # w2j_url = 'https://open.caldron.cn/wav2json-a7adc817c6'
            # w2j_param = {
            #     "hostapi_api_key": "nj8JSFPTgm2V7zl",
            #     "bs_type": "52",
            #     "input_url": WEB_PREFIX + dest_mp3_s3_url
            # }
            # http = urllib3.PoolManager()
            # res = http.request('POST', w2j_url, body=json.dumps(w2j_param),headers={'Content-Type': 'application/json'})
            # res_data = res.data.decode()
            # res_data = json.loads(res_data)
            # bs_url = ''
            # if res_data.get('taskid'):
            #     cnt = 0
            #     w2j_url_get = f"https://open.caldron.cn/wav2json-a7adc817c6?hostapi_api_key=nj8JSFPTgm2V7zl&taskid={res_data['taskid']}"
            #     while cnt < 60:
            #         res = http.request('GET', w2j_url_get)
            #         res_data_res = res.data.decode()
            #         res_data_res = json.loads(res_data_res)
            #         # print(type(res_data_res), res_data_res)
            #         if res_data_res.get('data') and res_data_res['data'].get('callback_data'):
            #             bs_url = res_data_res['data']['callback_data']['output_url']
            #             break
            #         elif res_data_res['code'] == 400:
            #             break
            #         cnt += 1
            #         time.sleep(2)
                    
            print('blendshape完成')
                    
            client = boto3.client('dynamodb')
            
            #write to DDB
            image_url='https://d2a5lerx865rzn.cloudfront.net/Slide6.jpeg'
            
            dynamodb = boto3.resource('dynamodb')
            table = dynamodb.Table('vr-demo')
            
            try:
                response = table.query(
                    IndexName='vr-module-index',
                    KeyConditionExpression=Key('vr_module').eq(vr_module),
                    FilterExpression=Attr('playing').eq(True)
                )
                # print(response)
                if 'Items' in response and len(response['Items']) >= 1:
                    response=response['Items'][0]
                    # print('Query response:', response, type(response))
                    
                    indexselected=response['index']
                    response=json.dumps(response, indent=4, cls=DecimalEncoder)
                    # print('Query response:', response,  type(response))
                 
                elif 'Items' in response and len(response['Items']) == 0:
                    response='noaction'
        
            except ClientError as e:
                print(e.response['Error']['Message'])
                response='noaction'
            # else:
                
            #     print('which one is true:', indexselected)
            
            try:
                response = table.update_item(
                    Key={
                        'demo_name': 'VR-demo',
                        'index': indexselected
                    },
                    UpdateExpression='SET playing = :val',
                    ConditionExpression='vr_module = :moduleId AND playing = :playingVal',
                    ExpressionAttributeValues={
                        ':moduleId': '0001',
                        ':playingVal': True,
                        ':val': False
                    }
                )
                print("UpdateItem succeeded:")
                # print(response)
            except Exception as e:
                print("Unable to update item:")
                print(e)
                
                
            client = boto3.client('dynamodb')
            response = client.put_item(
                TableName=DDB_TABLE,
                Item={
                    'demo_name': {'S': user_id},
                    'index': {'S': index},
                    'pic_path': {'S': image_url},
                    # 'bs_url': {'S': bs_url},
                    'audio_path': {'S': WEB_PREFIX + dest_mp3_s3_url},
                    'text': {'S': text},
                    'character': {'S': character},
                    'voice': {'S': voice},
                    'scene': {'S': scene},
                    'action': {'S': action},
                    'item_id': {'S': item_id},
                    'user_id': {'S': user_id},
                    'random_id': {'S': index},
                    'playing': {'BOOL': True},
                    'voice_speed': {'S': voice_speed},
                    'vr_module': {'S': vr_module},
                    'camera':{'S':camera}
                })
            print('数字人驱动。。。')
    return {
        'statusCode': 200,
        'headers': cors,
        'body': "success"
    }